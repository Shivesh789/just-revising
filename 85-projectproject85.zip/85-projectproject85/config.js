import firebase from "firebase";

const firebaseConfig = {
 apiKey: "AIzaSyD1Lmk2uXnJyVJLmA5M8bhh66WoyRT4KbA",
  authDomain: "ride-stage-f7c11.firebaseapp.com",
  projectId: "ride-stage-f7c11",
  storageBucket: "ride-stage-f7c11.appspot.com",
  messagingSenderId: "831127367664",
  appId: "1:831127367664:web:50c04e3f3022597f8cf735"}
//Initialize Firebase 
if(!firebase.apps.length)
 {  
    firebase.initializeApp(firebaseConfig);
     } 
     export default  firebase.firestore()
